#include "..\IVPlugIn.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define R 15
#define D 30
#define L 256
#define STEP 5

unsigned char Ball[D][D];

__declspec(dllexport) char *PlugInName()
{
     return "Moving ball (Demo)";
}

void InitializeBallPixels()
{
    double Q = 3.141593/2.5;
    int i, j;
    double xx, z;
    for (i = 0; i < D; i++) {
	xx = (double)((i-R)*(i-R));
	for (j = 0; j < D; j++) {
	    z = sqrt(xx+(double)((j-R)*(j-R)));
	    if (z < (double)R)
		Ball[i][j] = (unsigned char)floor(255.0*cos(z*Q/(double)R)+0.5);
	}
    }
}

void SetBallPixels(unsigned char * Data, unsigned char * Bmp, int x, int y)
{
    int i, j, yy;

    for (j = y-R; j < y+R; j++) {
	yy = j*L;
	for (i = x-R; i < x+R; i++) {
	    Data[yy+i] = Ball[i-x+R][j-y+R];
	    Bmp[yy+i]  = Ball[i-x+R][j-y+R];
	}
    }
}

void EraseBallPixels(unsigned char * Data, unsigned char * Bmp, int x, int y)
{
    int i, j, yy;

    for (j = y-R; j < y+R; j++) {
	yy = j*L;
	for (i = x-R; i < x+R; i++) {
	    Data[yy+i] = (unsigned char)0;
	    Bmp[yy+i]  = (unsigned char)0;
	}
    }
}

int IsTouched(int x, int y)
{
    int Q = 0;
    if ((x-R) <= 2)   Q += 1;
    if ((x+R) >= L-2) Q += 2;
    if ((y-R) <= 2)   Q += 4;
    if ((y+R) >= L-2) Q += 8;
    return Q;
}

__declspec(dllexport) void PlugInMain(int flags, PLUGINSERVER ps)
{
     HMATRIX iData, iBmp;
     unsigned char *Data;
     unsigned char *Bmp;
     HIMAGE image;
     IMAGEWINDOW imgwnd;
     int x, y, x1, y1, nStop = 0, Q, N = 0;
     double x0, y0, dx, dy, dx1, dy1;

     ivConnectPlugInServer(ps);

     InitializeBallPixels();
     iData = ivMTCreate(L, L, DATA_BYTE);
     image = ivIMCreateFromMatrix(iData);
     Data = (unsigned char *)ivMTGetPointer(iData);
     iBmp  = ivIMGetBmpBitsHandle(image);
     Bmp = (unsigned char *)ivMTGetPointer(iBmp);
     imgwnd = ivIWCreate(image, NULL);
     ivIMSetMinDisplayValue(image, 0.0);
     ivIMSetMaxDisplayValue(image, 255.0);

     srand((unsigned)time(NULL));
     x1 = x = ((int)rand()*(L-D-4))/(int)RAND_MAX+R+2;
     y1 = y = ((int)rand()*(L-D-4))/(int)RAND_MAX+R+2;
     x0 = (double)x;
     y0 = (double)y;

     SetBallPixels(Data, Bmp, x, y);
     dx = dy = 1.0;

     while (nStop == 0) {
	 N++;
	 Q = IsTouched(x, y);
	 if (Q != 0) {
	     dx1 = (double)(((int)rand()*6)/(int)RAND_MAX+5);
	     dy1 = (double)(((int)rand()*6)/(int)RAND_MAX+5);
	 }
	 switch (Q) {
	     case 0 : break;
	     case 1 : dx = dx1;
		      dy = (dy < 0.0) ? -dy1 : dy1; break;
	     case 2 : dx = -dx1;
		      dy = (dy < 0.0) ? -dy1 : dy1; break;
	     case 4 : dy = dy1;
                      dx = (dx < 0.0) ? -dx1 : dx1; break;
	     case 8 : dy = -dy1;
		      dx = (dx < 0.0) ? -dx1 : dx1; break;
	     case 5 : dx = dx1;
		      dy = dy1; break;
	     case 9 : dx = dx1;
		      dy = -dy1; break;
	     case 6 : dx = -dx1;
		      dy = dy1; break;
	     case 10 : dx = -dx1;
		      dy = -dy1; break;
	 }

	 if (fabs(dx) > fabs(dy)) {
	     x0 += (dx < 0.0) ? (-1.0) : 1.0;
	     y0 += (dy > 0.0) ? fabs(dy/dx) : -fabs(dy/dx);
	 } else {
	     y0 += (dy < 0.0) ? (-1.0) : 1.0;
	     x0 += (dx > 0.0) ? fabs(dx/dy) : -fabs(dx/dy);
	 }
	 x = (int)floor(x0+0.5);
	 y = (int)floor(y0+0.5);

	 if (N%STEP == 1) {
	     EraseBallPixels(Data, Bmp, x1, y1);
	     SetBallPixels(Data, Bmp, x, y);
	     x1 = x;
	     y1 = y;

	     ivProcessMessage();
	     nStop = ivGetStopCount();
	     ivIWRepaint(imgwnd, NULL, 0);
	 }
     }
}